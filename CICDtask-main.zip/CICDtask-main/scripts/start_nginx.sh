#!/bin/bash

sudo systemctl start nginx
sudo systemctl restart nginx

